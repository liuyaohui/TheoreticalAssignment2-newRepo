
public class Keypad
 {
 private static int input; // reads data from the command line
// no-argument constructor initializes the Scanner
 public static void setInput(int i){
		
	 input = i;
} // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
 return input; // we assume that user enters an integer
 } // end method getInput
 }