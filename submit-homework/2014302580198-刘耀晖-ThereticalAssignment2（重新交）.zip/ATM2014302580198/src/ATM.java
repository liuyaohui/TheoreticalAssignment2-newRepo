
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class ATM extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean userAuthenticated; // whether user is authenticated
	private int currentAccountNumber; // current user's account number
	private Screen screen; // ATM's screen
	private Keypad keypad; // ATM's keypad
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	
	//GUI����
	public static JTextArea jTextArea = new JTextArea();//�����ı���
	public JScrollPane jsp = new JScrollPane(jTextArea);
	public JButton jb1,jb2,jb3,jb4,jb5,jb6,jb7,jb8,jb9,jb0,jbEnter,jbBack;
	public Integer accountNumber = new Integer(0);
	public Integer pin = new Integer(1);
	public int tp = 0;
	
	public ATM(){
		super();
		this.setSize(800,600);
		this.setTitle("ATMģ���������");
		this.setVisible(true);
		this.setResizable(false);   
		this.setLayout(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.add(jsp);                                                          
		jsp.setBounds(200, 50, 400, 200);
		
		
		jb7 = new JButton("7");
		jb7.setBounds(300, 300, 50, 50);
		this.add(jb7);
		jb8 = new JButton("8");
		jb8.setBounds(350, 300, 50, 50);
		this.add(jb8);
		jb9 = new JButton("9");
		jb9.setBounds(400, 300, 50, 50);
		this.add(jb9);
		
		jb4 = new JButton("4");
		jb4.setBounds(300, 350, 50, 50);
		this.add(jb4);
		
		jb5 = new JButton("5");
		jb5.setBounds(350, 350, 50, 50);
		this.add(jb5);
		
		jb6 = new JButton("6");
		jb6.setBounds(400, 350, 50, 50);
		this.add(jb6);
		
		jb1 = new JButton("1");
		jb1.setBounds(300, 400, 50, 50);
		this.add(jb1);
		
		jb2 = new JButton("2");
		jb2.setBounds(350, 400, 50, 50);
		this.add(jb2);
		
		jb3 = new JButton("3");
		jb3.setBounds(400, 400, 50, 50);
		this.add(jb3);
		
		jb0 = new JButton("0");
		jb0.setBounds(300, 450, 50, 50);
		this.add(jb0);
		
		jbEnter = new JButton("Enter");
		jbEnter.setBounds(350, 450, 100, 50);
		this.add(jbEnter);
		
//		jbBack = new JButton("Backspace");
//		jbBack.setBounds(450, 450, 100, 50);
//		this.add(jbBack);
		
		class jbEnterListen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
				Keypad.setInput(tp);		
				tp = 0;
						
			}
		}
		jbEnter.addActionListener(new jbEnterListen());
		

		class jb1Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
				
						jTextArea.append("1" );
						tp = tp*10 + 1;
						Keypad.setInput(0);
			}
		}
		jb1.addActionListener(new jb1Listen());
		
		class jb2Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("2" );
						tp = tp*10 + 2;
						Keypad.setInput(0);
				   }
		}
		jb2.addActionListener(new jb2Listen());
		
		class jb3Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("3" );
						tp = tp*10 + 3;
						Keypad.setInput(0);
				   }
		}
		jb3.addActionListener(new jb3Listen());
		
		class jb4Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("4" );
						tp = tp*10 + 4;
						Keypad.setInput(0);
				   }
		}
		jb4.addActionListener(new jb4Listen());
		
		class jb5Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("5" );
						tp = tp*10 + 5;
						Keypad.setInput(0);
				   }
		}
		jb5.addActionListener(new jb5Listen());
		
		class jb6Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("6" );
						tp = tp*10 + 6;
						Keypad.setInput(0);
				   }
		}
		jb6.addActionListener(new jb6Listen());
		
		class jb7Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("7" );
						tp = tp*10 + 7;
						Keypad.setInput(0);
				   }
		}
		jb7.addActionListener(new jb7Listen());
		
		class jb8Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("8" );
						tp = tp*10 + 8;
						Keypad.setInput(0);
				   }
		}
		jb8.addActionListener(new jb8Listen());
		
		class jb9Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("9" );
						tp = tp*10 + 9;
						Keypad.setInput(0);
				   }
		}
		jb9.addActionListener(new jb9Listen());
		
		class jb0Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("0" );
						tp = tp*10 + 0;
						Keypad.setInput(0);
				   }
		}
		jb0.addActionListener(new jb0Listen());
		//ʹ���ڴ���ʾ���м䵯��
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				Dimension frameSize = this.getSize();
				if (frameSize.height > screenSize.height)
				    frameSize.height = screenSize.height;       
				if (frameSize.width > screenSize.width)
				    frameSize.width = screenSize.width;       
				this.setLocation((screenSize.width-frameSize.width)/2,(screenSize.height-frameSize.height) / 2);
			
	 
	
	// no-argument ATM constructor initializes instance variables
	 
	 userAuthenticated = false; // user is not authenticated to start
	 currentAccountNumber = 0; // no current account number to start
	 screen = new Screen(); // create screen
	 keypad = new Keypad(); // create keypad
	 cashDispenser = new CashDispenser(); // create cash dispenser
	 depositSlot = new DepositSlot(); // create deposit slot
	 bankDatabase = new BankDatabase(); // create account info database
	  } // end no-argument ATM constructor
	 // start ATM
	 public void run()
	  {
	  // welcome and authenticate user; perform transactions
	  while ( true )
	  {
	  // loop while user is not yet authenticated
	  while ( !userAuthenticated )
	  {
		  screen.displayMessage("Welcome");
		  authenticateUser(); // authenticate user
	  } // end while
	 
	  performTransactions(); // user is now authenticated
	  userAuthenticated = false; // reset before next ATM session
	  currentAccountNumber = 0; // reset before next ATM session
	  screen.displayMessageLine("\nThank you! Goodbye!\n" );
//	  while(true){
//		  
//	  }
	  } // end while
	  } // end method run
	 
	  // attempts to authenticate user against database
	  private void authenticateUser()
	  {
		  screen.displayMessage("\nPlease enter your account number: " );
		  while(accountNumber == 0){
			  	accountNumber = keypad.getInput(); // input account number
			  	pin = 0;
		  }
		  Keypad.setInput(tp);
		  screen.displayMessage("\nEnter your PIN: " ); // prompt for PIN
		  while(pin == 0){
	  			// input PIN
	  			pin = keypad.getInput();
	  		}
	  	  Keypad.setInput(tp);
	  // set userAuthenticated to boolean value returned by database
	 userAuthenticated =
	  bankDatabase.authenticateUser( accountNumber, pin );
	 
	  // check whether authentication succeeded
	  if ( userAuthenticated )
	 {
	  currentAccountNumber = accountNumber; // save user's account #
	  } // end if
	  else
		  screen.displayMessageLine("\nInvalid account number or PIN. Please try again.\n");
			accountNumber = 0;
			pin = 1;
	  } // end method authenticateUser
	 
	  // display the main menu and perform transactions
	  private void performTransactions()
	  {
	 // local variable to store transaction currently being processed
	  Transaction currentTransaction = null;
	  boolean userExited = false; // user has not chosen to exit
	 // loop while user has not chosen option to exit system
	   while ( !userExited )
	  {
	  // show main menu and get user selection
		   tp = 0;
		   Keypad.setInput(tp);
		   int mainMenuSelection = displayMainMenu();
	   // decide how to proceed based on user's menu selection
	   switch ( mainMenuSelection )
	   {
	  // user chose to perform one of three transaction types
	  case BALANCE_INQUIRY:
	  case WITHDRAWAL:
	  case DEPOSIT:
	   // initialize as new object of chosen type
	  currentTransaction =
	   createTransaction( mainMenuSelection );
	  currentTransaction.execute(); // execute transaction
	 break;
	   case EXIT: // user chose to terminate session
		   screen.displayMessageLine( "\nExiting the system..." );
	   userExited = true; // this ATM session should end
	   break;
	   default: // user did not enter an integer from 1-4
	   screen.displayMessageLine(
	   "\nYou did not enter a valid selection. Try again." );
	   break;
	   } // end switch
	   } // end while
	  } // end method performTransactions
	  
	   // display the main menu and return an input selection
	  private int displayMainMenu()
	   {
		  screen.displayMessageLine( "\nMain menu:" );
		  screen.displayMessageLine( "1 - View my balance" );
		  screen.displayMessageLine( "2 - Withdraw cash" );
		  screen.displayMessageLine( "3 - Deposit funds" );
		  screen.displayMessageLine( "4 - Exit\n" );
		  screen.displayMessage( "Enter a choice: " );
		  int choice = 0;
		  while(choice == 0){
			  
			  choice = keypad.getInput();
			  System.out.print(choice);
		  }
	   return choice; // return user's selection
	  } // end method displayMainMenu
	 
	  // return object of specified Transaction subclass
	  private Transaction createTransaction( int type )
	   {
	   Transaction temp = null; // temporary Transaction variable
	  switch ( type )
	  {
	   case BALANCE_INQUIRY: // create new BalanceInquiry transaction
	   temp = new BalanceInquiry(
	   currentAccountNumber, screen, bankDatabase );
	  break;
	   case WITHDRAWAL: // create new Withdrawal transaction
	   temp = new Withdrawal( currentAccountNumber, screen,
	  bankDatabase, keypad, cashDispenser );
	   break;
	   case DEPOSIT: // create new Deposit transaction
	   temp = new Deposit( currentAccountNumber, screen,
	   bankDatabase, keypad, depositSlot );
	   break;
	   } // end switch
	 
	   return temp; // return the newly created object
	   } // end method createTransaction
	   }
