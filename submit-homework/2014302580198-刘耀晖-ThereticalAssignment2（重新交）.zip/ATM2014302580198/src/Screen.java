
// Represents the screen of the ATM

public class Screen
 {
// display a message without a carriage return
 public void displayMessage( String message )
 {
	 ATM.jTextArea.append(message);
 } // end method displayMessage

 // display a message with a carriage return
 public void displayMessageLine( String message )
 {
	 ATM.jTextArea.append("\n"+message);
 } // end method displayMessageLine

 // displays a dollar amount
 public void displayDollarAmount( double amount )
 {
	 ATM.jTextArea.append(String.valueOf(amount));
 } // end method displayDollarAmount
 } // end class Screen