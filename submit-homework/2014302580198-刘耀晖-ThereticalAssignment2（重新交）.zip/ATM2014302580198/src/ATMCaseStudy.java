
public class ATMCaseStudy
 {
 // main method creates and runs the ATM
 public static void main( String[] args )
 {
 ATM theATM = new ATM();
 theATM.run();
 } // end main
 } // end class ATMCaseStudy