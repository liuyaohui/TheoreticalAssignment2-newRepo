

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class GUI extends JFrame{
	public static JTextArea jTextArea = new JTextArea();//�����ı������
	public JScrollPane jsp = new JScrollPane(jTextArea);
	public JButton jb1,jb2,jb3,jb4,jb5,jb6,jb7,jb8,jb9,jb0,jbEnter,jbBack;
	public Integer accountNumber = new Integer(0);
	public Integer pin = new Integer(1);
	
	public int tp = 0;
	
	
	public GUI(){
		super();
		this.setSize(800,600);
//		this.setLocation(300,50);
//		this.getContentPane().setLayout(null);
		this.setTitle("ATMģ���������");
		this.setVisible(true);
		this.setResizable(false);   
		this.setLayout(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

		this.add(jsp);                                                          
		jsp.setBounds(200, 50, 400, 200);
		
		jb7 = new JButton("7");
		jb7.setBounds(300, 300, 50, 50);
		this.add(jb7);
		jb8 = new JButton("8");
		jb8.setBounds(350, 300, 50, 50);
		this.add(jb8);
		jb9 = new JButton("9");
		jb9.setBounds(400, 300, 50, 50);
		this.add(jb9);
		
		jb4 = new JButton("4");
		jb4.setBounds(300, 350, 50, 50);
		this.add(jb4);
		
		jb5 = new JButton("5");
		jb5.setBounds(350, 350, 50, 50);
		this.add(jb5);
		
		jb6 = new JButton("6");
		jb6.setBounds(400, 350, 50, 50);
		this.add(jb6);
		
		jb1 = new JButton("1");
		jb1.setBounds(300, 400, 50, 50);
		this.add(jb1);
		
		jb2 = new JButton("2");
		jb2.setBounds(350, 400, 50, 50);
		this.add(jb2);
		
		jb3 = new JButton("3");
		jb3.setBounds(400, 400, 50, 50);
		this.add(jb3);
		
		jb0 = new JButton("0");
		jb0.setBounds(300, 450, 50, 50);
		this.add(jb0);
		
		jbEnter = new JButton("Enter");
		jbEnter.setBounds(350, 450, 100, 50);
		this.add(jbEnter);
//		jbBack = new JButton("Backspace");
//		jbBack.setBounds(450, 450, 100, 50);
//		this.add(jbBack);
		
		class jbEnterListen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
				
				Keypad.setInput(tp);		
				tp = 0;
						
			}
		}
		jbEnter.addActionListener(new jbEnterListen());
		
//		class jbBackListen implements ActionListener{
//			public void actionPerformed(ActionEvent e) {
//						tp = tp / 10;
//						int len =	String.valueOf(tp).length() -  1;
//						jTextArea.append(String.valueOf(tp).substring(0, len));
//			}
//		}
//		jbBack.addActionListener(new jbBackListen());
		
		class jb1Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
				
						jTextArea.append("1" );
						tp = tp*10 + 1;
						
			}
		}
		jb1.addActionListener(new jb1Listen());
		
		class jb2Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("2" );
						tp = tp*10 + 2;
				   }
		}
		jb2.addActionListener(new jb2Listen());
		
		class jb3Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("3" );
						tp = tp*10 + 3;
				   }
		}
		jb3.addActionListener(new jb3Listen());
		
		class jb4Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("4" );
						tp = tp*10 + 4;
				   }
		}
		jb4.addActionListener(new jb4Listen());
		
		class jb5Listen implements ActionListener{
			public void actionPerformed(ActionEvent e) {
						jTextArea.append("5" );
						tp = tp*10 + 5;
				   }
		}
		jb5.addActionListener(new jb5Listen());
		
		//ʹ���ڴ���ʾ���м䵯��
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				Dimension frameSize = this.getSize();
				if (frameSize.height > screenSize.height)
				    frameSize.height = screenSize.height;       
				if (frameSize.width > screenSize.width)
				    frameSize.width = screenSize.width;       
				this.setLocation((screenSize.width-frameSize.width)/2,(screenSize.height-frameSize.height) / 2);
			
	}
	
}
